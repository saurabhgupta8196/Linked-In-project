export interface DataStruct{
    "connection": [{"_id":string,
    "name":string,
    "profile":string
}]}
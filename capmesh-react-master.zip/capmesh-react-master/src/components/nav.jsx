import React, { Component } from 'react';

class Nav extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (
            <div>Nav..</div>
        );
    }
}
 
export default Nav;